public class Quotation {
  String quote = "Be yourself; everyone else is already taken.";
  String author = "Oscar Wilde";
  public void display() {
    System.out.println(quote);
    System.out.println(author);
  }
}
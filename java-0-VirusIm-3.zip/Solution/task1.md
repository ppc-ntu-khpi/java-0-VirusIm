## TASK ONE
- Tast 1.1: ![alt-текст](https://imgur.com/a/OKmqEdi)
- Tast 1.2: ![alt-текст](https://imgur.com/a/OKmqEdi)
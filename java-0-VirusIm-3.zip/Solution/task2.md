## TASK TWO
- Tast 2.1: ![alt-текст](https://imgur.com/a/OKmqEdi)
- Tast 2.2: ![alt-текст](https://imgur.com/a/OKmqEdi)